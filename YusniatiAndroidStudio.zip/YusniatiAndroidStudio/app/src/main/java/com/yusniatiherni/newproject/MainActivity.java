package com.yusniatiherni.newproject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final Button toast  = (Button) findViewById(R.id.BtnToast);
        toast.setOnClickListener(view -> Toast.makeText(MainActivity.this, "Harap Tunggu... Sedang Loading", Toast.LENGTH_SHORT).show());
       final Button scroll = (Button) findViewById(R.id.BtnScroll);
        scroll.setOnClickListener(view -> {
            Intent scroll1 = new Intent(getApplicationContext(), ScrollView.class);
            startActivity(scroll1);
        });
           
        final Button alert = (Button) findViewById(R.id.BtnAlert);
        alert.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);


            builder.setTitle("perhatian...");

            builder.setMessage("Apa Anda Yakin Ingin Keluar?");

            builder.setPositiveButton("Ya", (dialogInterface, i) -> finish());

            builder.setNegativeButton("Tidak", (dialogInterface, i) -> {

            });
            builder.setNegativeButton("Tidak", (dialogInterface, i) -> {

            });
            builder.setNeutralButton("Kembali", (dialogInterface, i) -> Toast.makeText(context, "Tetep Di Aplikasi", Toast.LENGTH_SHORT).show());
            builder.show();
        });

        final Button gambar = (Button) findViewById(R.id.BtnGambar);

        gambar.setOnClickListener(view -> {

            Intent gambar1 = new Intent(getApplicationContext(),Gambar.class);
            startActivity(gambar1);
        });




    }
}